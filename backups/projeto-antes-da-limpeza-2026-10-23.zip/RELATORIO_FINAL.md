# Entrega da migração e evolução do VerificaFato

## Projeto alterado
A pasta informada no ambiente não existia. A implementação foi realizada em:
C:/Users/Luiz/Documents/VerficaFato-IFPR-main (1)/VerficaFato-IFPR-main

Esta cópia não contém .git; não foram criados commits ou PRs. Originais alterados estão em .migration-backup/backend, frontend e core. O arquivo .env, imagens e acervos existentes foram preservados.

## Implementado
- Backend ESM compartilhado entre servidor local e Vercel; contratos de conta/perfil/histórico/admin mantidos.
- Nove módulos de coleta JavaScript substituem a execução normal dos módulos Python, com seis fontes, extração, datas, deduplicação, JSON/JSONL/CSV, MongoDB e importação EN→PT. Python permanece como referência histórica, sem dependência de execução.
- Entrada texto/URL e pipeline modular por afirmação, com consultas Google, cache, fontes, datas, classificações conservadoras e exposição explícita de limitações.
- TensorFlow.js ativo no cálculo lexical, carregamento opcional de embeddings locais e separação entre linguagem e evidência.
- Explicação local completa e camada externa com Gemini preferencial, mantendo OpenAI como alternativa por AI_PROVIDER. Os dois adaptadores usam schema e validação local restritos a textos/destaques autorizados; o modelo não pode criar fontes ou mudar a classificação. geracao.provedor identifica o provedor selecionado.
- Resultado compartilhado em sete seções, preservando design, temas e navegação. Histórico novo guarda resultado integral; dados antigos são tratados como legado.
- Proteções contra SSRF, XSS e operadores Mongo; JWT sem segredo padrão, sessões revogáveis, schemas, sanitização, CSP, CORS, rate limit, timeout total/cancelamento, filas e métricas agregadas privadas.
- Dependências auditadas e vulnerabilidade transitiva crítica corrigida.

## Validação
A validação da migração anterior incluiu testes automatizados, análise de sintaxe, auditoria de dependências e inspeção visual em Chrome desktop e celular. A inclusão do adaptador Gemini exige uma nova rodada de validação, ainda pendente neste registro; os resultados anteriores não comprovam o funcionamento do novo provedor.
Veja [a validação detalhada](docs/VALIDACAO.md) para a cobertura já registrada, métodos e limites.

## Ativação e pendências
Contas, histórico e administração dependem de MongoDB e JWT_SECRET; checagens publicadas dependem de GOOGLE_API_KEY. As credenciais e os serviços reais exigem homologação no ambiente do operador.

Para explicações externas com o provedor preferencial, configure AI_PROVIDER=gemini, GEMINI_API_KEY e GEMINI_MODEL, usando um identificador disponível na conta e compatível com saída estruturada. Não há modelo padrão presumido. O exemplo mantém ENABLE_AI_EXPLANATION=false; o envio só é habilitado ao definir true. GOOGLE_API_KEY da Fact Check Tools é separada de GEMINI_API_KEY: usar Gemini não substitui as checagens Google nem a análise TensorFlow.js.

A alternativa OpenAI permanece disponível com AI_PROVIDER=openai, OPENAI_API_KEY e OPENAI_MODEL. Os dois provedores obedecem ao mesmo contrato de textos autorizados e à validação local; falhas usam a explicação local. O arquivo .env real não foi lido nem alterado nesta atualização de documentação.
Não há pesos semânticos treinados para português no repositório. O TensorFlow executa comparação lexical real; inferência semântica requer modelo compatível e avaliação real descritos em [MODELOS.md](docs/MODELOS.md).
O modo --selenium permanece como adaptador opcional de navegador estático, com JavaScript externo desativado por segurança. Páginas que dependem de executar scripts devem ser analisadas a partir do texto colado.
Não houve deploy nem alteração dos dados do usuário. Cache, métricas e rate limit são por processo; produção distribuída exige infraestrutura compartilhada e revisão dos limites do provedor.

Para executar/configurar: [README](README.md) e [.env.example](.env.example).
Metodologia: [METODOLOGIA.md](docs/METODOLOGIA.md).
Auditoria: [SEGURANCA.md](docs/SEGURANCA.md).
Coletor: [SCRAPER.md](docs/SCRAPER.md).

# Diagnóstico e plano de migração

Inspeção em 23/10/2026. A pasta configurada no chat não existia; o código foi encontrado em Documents/VerficaFato-IFPR-main (1)/VerficaFato-IFPR-main. Esta cópia não contém diretório .git.

## Estado inicial
Backend Express/Mongoose CommonJS duplicado em server.js e api/index.js. Frontend estático com autenticação, perfil, histórico, administração, fontes e educação. Dez módulos Python implementam coleta, extração e exportação; testes pytest e dados PT/EN estão preservados.
Google Fact Check estava integrado; não havia TensorFlow nem modelo generativo. Texto já era aceito, com limite cliente de 2000 caracteres. O resultado misturava estilo textual com veracidade e elevava correspondências regionais a 88% sem validação.

Problemas encontrados: SSRF e redirecionamentos sem validação; segredo JWT padrão público; expiração opcional; consultas sem schemas; CORS aberto; ausência de rate limit; XSS persistente em nomes/HTML e resultados externos; logs de conteúdo e erros externos; banco indisponível podia travar rotas; duplicação dos motores e backends.

## Etapas
1. Preservar originais modificados em .migration-backup, sem copiar segredos nem dados pessoais.
2. Converter backend, modelos, rotas e coletor para ES Modules, unificando deploy e servidor local.
3. Separar entrada, extração segura, afirmações, busca Google, análise TensorFlow, consolidação e explicação.
4. Aplicar classificação conservadora baseada em correspondências verificáveis, sem porcentagens arbitrárias; notícias regionais são contexto.
5. Evoluir somente os componentes de resultado das telas existentes.
6. Testar componentes reais e falhas de integrações com transportes injetados. Testes não usam chaves nem enviam notícias reais a terceiros.
7. Documentar credenciais, limites, modelos, operação e verificações executadas.

## Compatibilidade e limites
Envelope /api/verificar continua {sucesso,dados}; campos antigos porcentagem/confianca passam a null pois não existe metodologia calibrada. Histórico novo guarda resultado completo. Registros anteriores permanecem legados.
Python e seus testes ficam como referência histórica; execução normal e coleta usam Node.js. Arquivos de dados existentes não são sobrescritos pela migração.

# Validação executada — 23/10/2026

Ambiente: Windows, Node.js v22.18.0 e npm 10.9.3. Validação final executada na cópia localizada em Documents/VerficaFato-IFPR-main (1)/VerficaFato-IFPR-main.

## Resultado final
- npm test: **95 testes, 95 passaram, zero falhas, zero cancelados, zero ignorados**.
- npm run check: **49 arquivos JavaScript com sintaxe válida** e manifestos JSON válidos.
- npm audit --json: **zero vulnerabilidades conhecidas reportadas** nas dependências instaladas. A atualização de proxy-addr corrigiu o achado crítico inicial; esse resultado não representa uma garantia de segurança absoluta.
- node scraper/coleta.js --help: saída 0, seis fontes e opções legadas apresentadas, sem executar coleta.

| Arquivo | Testes | Escopo |
|---|---:|---|
| tests/analysis.test.js | 27 | URL/texto, múltiplas afirmações, evidência, Google, TensorFlow real, IA restrita, contexto, falhas, filas e cancelamento |
| tests/backend.test.js | 21 | HTTP, JWT, senha, conta ativa, autorização, CORS/CSP, rate limit, histórico, sanitização, métricas e fluxo HTTP real |
| tests/frontend.test.js | 13 | DOM, sete seções, XSS, URLs, legado, perfil, sessão e CRUD administrativo |
| tests/safe-http.test.js | 6 | IP/DNS, redirects, fixação do IP, limites de tempo/bytes e regras por destino |
| tests/scraper.test.js | 28 | Extração, datas, contratos, deduplicação, importação EN/PT, persistência e coletores |

## Cenários solicitados
Os quatorze cenários do pedido estão cobertos: URL; texto integral; afirmação curta; várias afirmações; checagem correspondente; nenhum resultado; estilo sensacionalista com evidência favorável; texto neutro contradito por fonte; falha Google; falha TensorFlow; SSRF/prompt injection; entrada inválida/longa; evidências contraditórias; IA indisponível.

Regressões adicionais impedem correspondência falsa entre 10² e 102, entre 1 MW e 1 mW, entre negação e afirmação, e conclusão global que ignore trechos curtos/números omitidos. Consultas parciais e avaliações contraditórias continuam inconclusivas.

As chamadas Google/OpenAI, DNS e rede externa são substituídas nos testes. TensorFlow.js/TF-IDF e o pipeline HTTP também foram executados de fato. MongoDB é simulado nos testes; exportações usam diretórios temporários e não os dados do usuário. Os testes de persistência exigem permissão para gravar nesses diretórios.

## Inspeção visual
Chrome headless executou a interface real com fixture local, sem banco, Google ou OpenAI. Desktop 1440 px e celular 390 px não apresentaram overflow horizontal. O formulário, temas e resultado foram inspecionados visualmente; sete seções aparecem no modal, sem duplicação de afirmações ou limitações.
Capturas em .artifacts/home-desktop.png, home-mobile.png, result-desktop.png e result-desktop-bottom.png. Fixture reproduzível em .artifacts/visual-check.mjs. Servidor e navegador da validação foram encerrados.

## Limites da validação
Não houve chamada a Google/MongoDB/OpenAI com credenciais reais, coleta de portais, execução de scripts externos de notícia, migração dos arquivos de acervo ou deploy. A configuração foi verificada somente por presença: Google, MongoDB e JWT seguro estão definidos; IA externa está desabilitada/sem chave+modelo; modelo semântico local não foi configurado.

Nenhum modelo semântico treinado foi fornecido ou avaliado. Nenhuma métrica de qualidade factual foi inventada. A ativação dessas integrações exige homologação com serviços e modelos reais.

// Compatibilidade ESM: sinais de linguagem nunca são convertidos em veracidade.
import { languageIndicators } from './services/claims.js';
import { VERDICTS, mapRating } from './services/evidence.js';
export { mapRating as mapearAvaliacaoAPI };
export function analisarTextoLocalmente(texto) {
  return { indicadores:languageIndicators(texto),alertasFalso:[],alertasConfiavel:[],pesoFalso:null,pesoConfiavel:null };
}
export function analisarDimensoesNoticia(texto) { return { linguagem:languageIndicators(texto),limite:'Indicadores linguísticos não avaliam verdade factual.' }; }
export function calcularVeredictoFinal() {
  return {porcentagem:null,confianca:null,veredito:VERDICTS.UNKNOWN,fonte:'sem_evidencias'};
}
export function obterRotuloVeredicto() { return VERDICTS.UNKNOWN; }

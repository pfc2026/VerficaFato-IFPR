import { element, appendSafeLink } from './safe-dom.js';
const STYLES = {
  'Verdadeiro': 'bg-success', 'Falso': 'bg-danger',
  'Parcialmente verdadeiro': 'bg-warning text-dark', 'Enganoso': 'bg-warning text-dark',
  'Sem evidências suficientes': 'bg-secondary', 'Não verificável': 'bg-secondary'
};
const list = value => Array.isArray(value) ? value : [];
const text = value => typeof value === 'string' ? value : '';
export function normalizeResult(record = {}) {
  if (record?.resultado?.schemaVersion === 2) return record.resultado;
  if (record?.schemaVersion === 2) return record;
  return {
    schemaVersion: 1, legado: true, veredito: 'Sem evidências suficientes',
    resumo: text(record.texto) || 'Consulta armazenada antes da atualização da metodologia.',
    justificativa: 'Registro legado: a pontuação e o veredito anteriores não foram revalidados com a metodologia atual.',
    afirmacoes: [], resultados: list(record.dadosAPI), fontes: [],
    limitacoes: ['Este registro é anterior à análise por afirmação. Faça uma nova consulta para obter uma verificação atual.'], secoes: {}
  };
}
export function resultLabel(record) {
  const data = normalizeResult(record);
  return data.legado ? 'Registro legado' : (Object.hasOwn(STYLES, data.veredito) ? data.veredito : 'Sem evidências suficientes');
}
export function resultBadge(record) {
  const label = resultLabel(record);
  return element('span', 'badge badge-veredito ' + (STYLES[label] || 'bg-secondary'), label);
}
function paragraph(parent, value, className = '') {
  if (value) parent.append(element('p', className, value));
}
function bulletList(parent, entries) {
  if (!entries.length) return;
  const ul = element('ul', 'analysis-list');
  entries.forEach(value => ul.append(element('li', '', value)));
  parent.append(ul);
}
function section(parent, heading) {
  const node = element('section', 'verification-section mb-3 p-3');
  node.append(element('h3', 'h6 mb-2', heading));
  parent.append(node);
  return node;
}
function reviewCard(parent, review) {
  const card = element('article', 'verification-item mb-2 p-3');
  paragraph(card, text(review.titulo_verificacao), 'fw-semibold mb-1');
  paragraph(card, text(review.texto_verificado), 'small mb-1');
  paragraph(card, [text(review.verificador), text(review.data_verificacao)].filter(Boolean).join(' · '), 'small mb-1');
  if (review.avaliacao) paragraph(card, 'Avaliação publicada: ' + text(review.avaliacao), 'small');
  if (review.url_verificacao) appendSafeLink(card, review.url_verificacao, 'Ler a checagem original', 'analysis-source-link');
  paragraph(card, 'Compare a afirmação, a data e o contexto da checagem com o conteúdo enviado.', 'small opacity-75 mb-0');
  parent.append(card);
}
export function renderAnalysis(container, record) {
  const data = normalizeResult(record);
  const sections = data.secoes || {};
  const output = document.createDocumentFragment();
  const summary = section(output, 'Resumo da análise');
  paragraph(summary, text(data.resumo) || text(sections.resumo) || 'O conteúdo enviado foi analisado para identificar afirmações verificáveis.');
  if (data.noticia?.url) appendSafeLink(summary, data.noticia.url, data.noticia.titulo || 'Conteúdo enviado', 'analysis-source-link');
  const conclusion = section(output, 'Resultado da verificação');
  conclusion.append(resultBadge(data));
  paragraph(conclusion, text(data.justificativa) || text(sections.resultado) || text(data.explicacao) || 'As evidências disponíveis não permitem concluir.');
  const findings = section(output, 'O que encontramos');
  const claims = list(data.afirmacoes);
  if (!claims.length) paragraph(findings, text(sections.encontramos));
  for (const claim of claims) {
    const card = element('article', 'analysis-claim mb-2 p-3');
    paragraph(card, text(claim.texto), 'fw-semibold mb-1');
    const classification = Object.hasOwn(STYLES, claim.veredito) ? claim.veredito : 'Sem evidências suficientes';
    paragraph(card, classification, 'small fw-semibold mb-1');
    if (['opiniao','previsao','instrucao'].includes(claim.tipo)) paragraph(card, {opiniao:'Opinião',previsao:'Previsão',instrucao:'Instrução'}[claim.tipo], 'small opacity-75');
    paragraph(card, text(claim.justificativa), 'small mb-1');
    for (const evidence of list(claim.evidencias)) {
      if (typeof evidence === 'string') continue;
      paragraph(card, text(evidence.justificativa) || text(evidence.texto_verificado) || text(evidence.titulo_verificacao), 'small');
      if (evidence.url_verificacao || evidence.url) appendSafeLink(card, evidence.url_verificacao || evidence.url, 'Consultar evidência', 'analysis-source-link');
    }
    findings.append(card);
  }
  list(data.resultados).forEach(review => reviewCard(findings, review));
  if (!claims.length && !list(data.resultados).length) paragraph(findings, data.legado ? 'O registro antigo não contém análise individual de afirmações.' : 'Nenhuma checagem correspondente permitiu verificar uma afirmação.');
  if (list(data.noticiasRegionais).length) {
    paragraph(findings, 'Reportagens regionais relacionadas fornecem contexto. A semelhança com uma reportagem não comprova a afirmação.', 'small');
    data.noticiasRegionais.forEach(item => {
      const itemNode = element('div', 'mb-2');
      appendSafeLink(itemNode, item.url, item.titulo || 'Reportagem regional', 'analysis-source-link');
      paragraph(itemNode, [item.fonte, item.data_publicacao].filter(Boolean).join(' · '), 'small');
      findings.append(itemNode);
    });
  }
  const language = section(output, 'Análise de linguagem');
  paragraph(language, text(sections.linguagem) || 'Características da linguagem ajudam a interpretar a mensagem e não constituem prova de veracidade ou falsidade.');
  const linguistic = data.analiseLinguagem || {};
  const indicators = list(linguistic.indicadores);
  const narrative = text(sections.linguagem);
  if (!indicators.every(item => narrative.includes(text(item.label)) && (!item.trecho || narrative.includes(text(item.trecho))))) {
    bulletList(language, indicators.map(item => text(item.label) + (item.trecho ? ': “' + text(item.trecho) + '”' : '')));
  }
  const tensorflow = linguistic.tensorflow;
  if (tensorflow) paragraph(language, tensorflow.disponivel ? 'Apoio do TensorFlow.js: ' + [tensorflow.metodo, tensorflow.modelo].filter(Boolean).join(' · ') : 'O modelo de linguagem do TensorFlow.js não estava disponível nesta análise.', 'small opacity-75');
  const sources = section(output, 'Fontes consultadas');
  const sourceList = list(data.fontes).length ? data.fontes : list(data.resultados).map(review => ({
    titulo: review.titulo_verificacao, url: review.url_verificacao, verificador: review.verificador, data: review.data_verificacao, tipo: 'checagem'
  }));
  if (!sourceList.length) paragraph(sources, 'Nenhuma fonte externa foi usada para sustentar uma conclusão factual.');
  sourceList.forEach(source => {
    const sourceNode = element('div', 'analysis-source mb-2');
    appendSafeLink(sourceNode, source.url, source.titulo || source.verificador || 'Consultar fonte', 'analysis-source-link');
    paragraph(sourceNode, [source.verificador, source.data, source.tipo === 'noticia' ? 'Reportagem de contexto' : 'Checagem publicada'].filter(Boolean).join(' · '), 'small mb-0');
    sources.append(sourceNode);
  });
  const guidance = section(output, 'Orientação ao usuário');
  paragraph(guidance, text(sections.orientacao) || 'Confira as fontes originais e o contexto antes de compartilhar. Quando faltarem evidências, trate a afirmação como não confirmada.');
  const limits = section(output, 'Limitações');
  const limitations = [...new Set([...list(data.limitacoes), ...list(tensorflow?.limitacoes), data.avisoHistorico].filter(value => typeof value === 'string' && value))];
  const limitationsProse = text(sections.limitacoes);
  const sameLimitations = limitationsProse.replace(/\s+/g,' ').trim() === limitations.join(' ').replace(/\s+/g,' ').trim();
  if (limitationsProse && !sameLimitations) paragraph(limits, limitationsProse);
  bulletList(limits, limitations);
  if (!limitations.length && !sections.limitacoes) paragraph(limits, 'A análise depende das fontes disponíveis e pode não abranger todos os detalhes, datas ou contextos.');
  container.replaceChildren(output);
  return data;
}

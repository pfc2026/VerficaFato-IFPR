"""Modulo de extracao de informacoes de documentos HTML."""

import json
import re
from typing import Any, Dict, List, Optional
from urllib.parse import urljoin, urlparse

from bs4 import BeautifulSoup, Tag

from .normalizers import normalize_text, normalize_url, parse_and_normalize_date
from .validators import is_safe_url

TAGS_REMOVER = [
    "script",
    "style",
    "noscript",
    "iframe",
    "nav",
    "header",
    "footer",
    "aside",
    "form",
    "button",
]

CLASSES_REMOVER = [
    re.compile(r"cookie", re.I),
    re.compile(r"comentario", re.I),
    re.compile(r"compartilh", re.I),
    re.compile(r"social-share", re.I),
    re.compile(r"publicidade", re.I),
    re.compile(r"banner", re.I),
    re.compile(r"relacionad", re.I),
    re.compile(r"sidebar", re.I),
    re.compile(r"widget", re.I),
    re.compile(r"anuncio", re.I),
]


class NewsExtractor:
    """Extrai campos estruturados (titulo, texto, data e links) a partir de HTML."""

    def __init__(self, soup: BeautifulSoup, base_url: str):
        self.raw_soup = soup
        self.base_url = base_url
        self.clean_soup = self._clean_tree(soup)

    @classmethod
    def from_html(cls, html_content: str, base_url: str) -> "NewsExtractor":
        soup = BeautifulSoup(html_content, "html.parser")
        return cls(soup, base_url)

    def _clean_tree(self, soup: BeautifulSoup) -> BeautifulSoup:
        """Cria uma copia da arvore DOM removendo elementos irrelevantes e anuncios."""
        tree = BeautifulSoup(str(soup), "html.parser")
        for tag_name in TAGS_REMOVER:
            for element in tree.find_all(tag_name):
                element.decompose()

        for pattern in CLASSES_REMOVER:
            for element in tree.find_all(class_=pattern):
                element.decompose()
            for element in tree.find_all(id=pattern):
                element.decompose()

        return tree

    def extract_title(self, custom_selector: Optional[str] = None) -> str:
        """Extrai o titulo da noticia respeitando ordem de prioridade definida."""
        # 1. Seletor customizado da fonte
        if custom_selector:
            elem = self.raw_soup.select_one(custom_selector)
            if elem and elem.get_text(strip=True):
                return normalize_text(elem.get_text())

        # 2. OpenGraph / Twitter Card
        for meta_name in ("og:title", "twitter:title"):
            tag = self.raw_soup.find("meta", property=meta_name) or self.raw_soup.find("meta", attrs={"name": meta_name})
            if tag and tag.get("content"):
                return normalize_text(tag["content"])

        # 3. Elemento h1 dentro de article ou no topo
        h1 = self.clean_soup.find("h1")
        if h1 and h1.get_text(strip=True):
            return normalize_text(h1.get_text())

        # 4. JSON-LD Schema.org
        json_ld_data = self._extract_json_ld()
        for item in json_ld_data:
            if isinstance(item, dict) and "headline" in item:
                return normalize_text(str(item["headline"]))

        # 5. Tag title HTML padrao
        if self.raw_soup.title and self.raw_soup.title.string:
            title_text = self.raw_soup.title.string
            # Limpa sufixos comuns como " - Jornal XYZ"
            title_cleaned = re.split(r"[-|–—]\s*[^|–—]+$", title_text)[0]
            return normalize_text(title_cleaned)

        return ""

    def extract_date(self, custom_selector: Optional[str] = None) -> Optional[str]:
        """Extrai e normaliza a data de publicacao respeitando ordem de prioridade."""
        # 1. Seletor customizado
        if custom_selector:
            elem = self.raw_soup.select_one(custom_selector)
            if elem:
                candidato = elem.get("datetime") or elem.get("content") or elem.get_text()
                parsed = parse_and_normalize_date(candidato)
                if parsed:
                    return parsed

        # 2. Meta tags article:published_time / pubdate
        meta_chaves = [
            ("property", "article:published_time"),
            ("name", "article:published_time"),
            ("property", "og:published_time"),
            ("name", "pubdate"),
            ("name", "publishdate"),
            ("name", "date"),
        ]
        for attr, chave in meta_chaves:
            tag = self.raw_soup.find("meta", attrs={attr: chave})
            if tag and tag.get("content"):
                parsed = parse_and_normalize_date(tag["content"])
                if parsed:
                    return parsed

        # 3. JSON-LD datePublished
        json_ld_data = self._extract_json_ld()
        for item in json_ld_data:
            if isinstance(item, dict):
                for campo in ("datePublished", "dateCreated", "uploadDate"):
                    if campo in item and isinstance(item[campo], str):
                        parsed = parse_and_normalize_date(item[campo])
                        if parsed:
                            return parsed

        # 4. Elementos time do HTML5
        for time_tag in self.clean_soup.find_all("time"):
            candidato = time_tag.get("datetime") or time_tag.get_text()
            parsed = parse_and_normalize_date(candidato)
            if parsed:
                return parsed

        # 5. Containers e spans comuns de data em layouts de portais
        for sel in (".posted-on", ".entry-date", ".data-publicacao", ".post-date", ".data", "[itemprop='datePublished']"):
            elem = self.raw_soup.select_one(sel)
            if elem:
                candidato = elem.get("datetime") or elem.get("content") or elem.get_text()
                parsed = parse_and_normalize_date(candidato)
                if parsed:
                    return parsed

        return None

    def extract_text(self, custom_selector: Optional[str] = None) -> str:
        """Extrai o texto do corpo da materia sem menus ou elementos auxiliares."""
        # 1. Seletor customizado
        if custom_selector:
            elem = self.clean_soup.select_one(custom_selector)
            if elem:
                paragrafos = [p.get_text(strip=True) for p in elem.find_all("p") if len(p.get_text(strip=True)) > 20]
                if paragrafos:
                    return normalize_text("\n\n".join(paragrafos))
                return normalize_text(elem.get_text())

        # 2. Elemento semantico article
        article = self.clean_soup.find("article")
        if article:
            paragrafos = [p.get_text(strip=True) for p in article.find_all("p") if len(p.get_text(strip=True)) > 20]
            if len(paragrafos) >= 2:
                return normalize_text("\n\n".join(paragrafos))
            texto_artigo = article.get_text(separator="\n", strip=True)
            if len(texto_artigo) > 100:
                return normalize_text(texto_artigo)

        # 3. Containers comuns de conteudo
        for container_sel in (".entry-content", ".noticia-texto", ".post-content", ".content-text", "#materia-conteudo"):
            elem = self.clean_soup.select_one(container_sel)
            if elem:
                paragrafos = [p.get_text(strip=True) for p in elem.find_all("p") if len(p.get_text(strip=True)) > 20]
                if paragrafos:
                    return normalize_text("\n\n".join(paragrafos))

        # 4. Fallback: Coleta paragrafos gerais com conteudo substancial
        paragrafos_gerais = [
            p.get_text(strip=True)
            for p in self.clean_soup.find_all("p")
            if len(p.get_text(strip=True)) > 35
        ]
        if paragrafos_gerais:
            return normalize_text("\n\n".join(paragrafos_gerais))

        return ""

    def _extract_json_ld(self) -> List[Dict[str, Any]]:
        """Extrai blocos JSON-LD estruturados da pagina."""
        resultados = []
        for script in self.raw_soup.find_all("script", type="application/ld+json"):
            if not script.string:
                continue
            try:
                data = json.loads(script.string.strip())
                if isinstance(data, list):
                    resultados.extend(data)
                elif isinstance(data, dict):
                    if "@graph" in data and isinstance(data["@graph"], list):
                        resultados.extend(data["@graph"])
                    else:
                        resultados.append(data)
            except (json.JSONDecodeError, TypeError):
                continue
        return resultados

    def extract_links(
        self,
        link_selector: Optional[str] = None,
        allowed_domains: Optional[List[str]] = None,
        url_pattern: Optional[str] = None,
    ) -> List[str]:
        """Extrai URLs de noticias a partir de uma pagina de listagem ou capa."""
        links_coletados = []
        elementos = (
            self.raw_soup.select(link_selector)
            if link_selector
            else self.raw_soup.find_all("a", href=True)
        )

        for elem in elementos:
            href = elem.get("href")
            if not href:
                continue

            # Converte links relativos para absolutos
            url_absoluta = urljoin(self.base_url, href)
            url_norm = normalize_url(url_absoluta)

            # Valida esquema e dominios autorizados
            valido, _ = is_safe_url(url_norm, allowed_domains=allowed_domains)
            if not valido:
                continue

            # Se houver regex restritivo de caminho da noticia
            if url_pattern and not re.search(url_pattern, url_norm):
                continue

            if url_norm not in links_coletados:
                links_coletados.append(url_norm)

        return links_coletados

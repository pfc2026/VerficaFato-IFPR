"""Modulo de validacao de integridade de dados e prevencao de SSRF."""

import ipaddress
import re
import socket
from typing import List, Optional, Tuple
from urllib.parse import urlparse

from .models import NewsItem


def is_private_or_loopback_ip(ip_str: str) -> bool:
    """Verifica se o IP e privado, loopback, link-local ou reservado."""
    try:
        ip_obj = ipaddress.ip_address(ip_str)
        return (
            ip_obj.is_private
            or ip_obj.is_loopback
            or ip_obj.is_link_local
            or ip_obj.is_reserved
            or ip_obj.is_multicast
            or ip_obj.is_unspecified
        )
    except ValueError:
        return False


def is_safe_url(
    url: str, allowed_domains: Optional[List[str]] = None, check_dns: bool = False
) -> Tuple[bool, str]:
    """Valida a URL contra esquemas invalidos, dominios nao autorizados e SSRF."""
    if not url or not isinstance(url, str):
        return False, "URL vazia ou com tipo de dado invalido."

    url_limpa = url.strip()
    try:
        parsed = urlparse(url_limpa)
    except Exception as exc:
        return False, f"Falha ao interpretar a URL: {exc}"

    if parsed.scheme.lower() not in ("http", "https"):
        return False, f"Esquema invalido: '{parsed.scheme}'. Apenas HTTP e HTTPS sao permitidos."

    hostname = (parsed.hostname or "").lower()
    if not hostname:
        return False, "URL sem hostname valido."

    # Bloqueio imediato de literais de loopback e link-local comuns
    if hostname in ("localhost", "127.0.0.1", "::1", "0.0.0.0"):
        return False, f"Destino nao permitido por politica de seguranca (loopback): '{hostname}'."

    # Verifica se o proprio hostname e um IP e se ele e restrito
    if is_private_or_loopback_ip(hostname):
        return False, f"Destino IP restrito por politica de seguranca: '{hostname}'."

    # Se check_dns estiver habilitado, resolve o IP para evitar DNS rebinding
    if check_dns:
        try:
            addr_info = socket.getaddrinfo(hostname, None)
            for item in addr_info:
                ip_resolved = item[4][0]
                if is_private_or_loopback_ip(ip_resolved):
                    return False, f"Hostname '{hostname}' resolve para IP restrito: {ip_resolved}."
        except socket.gaierror:
            return False, f"Nao foi possivel resolver o hostname '{hostname}' via DNS."

    # Validacao contra lista de dominios autorizados
    if allowed_domains:
        dominios_autorizados = [d.lower().lstrip(".") for d in allowed_domains if d]
        dominio_valido = False
        for permitido in dominios_autorizados:
            if hostname == permitido or hostname.endswith("." + permitido):
                dominio_valido = True
                break
        if not dominio_valido:
            return False, f"Dominio '{hostname}' nao consta na lista de dominios autorizados."

    return True, "URL segura e autorizada."


def validate_news_item(
    item: NewsItem,
    min_title_len: int = 5,
    min_text_len: int = 40,
    allowed_domains: Optional[List[str]] = None,
) -> Tuple[bool, Optional[str]]:
    """Valida se o registro atende rigorosamente ao contrato de dados estabelecido."""
    if not isinstance(item, NewsItem):
        return False, "O objeto fornecido nao e uma instancia de NewsItem."

    # 1. Titulo
    if not item.titulo or not isinstance(item.titulo, str):
        return False, "Titulo ausente ou invalido."
    if len(item.titulo.strip()) < min_title_len:
        return False, f"Titulo muito curto ({len(item.titulo.strip())} caracteres). Minimo: {min_title_len}."

    # 2. Texto
    if not item.texto or not isinstance(item.texto, str):
        return False, "Texto da noticia ausente ou invalido."
    if len(item.texto.strip()) < min_text_len:
        return False, f"Texto insuficiente ({len(item.texto.strip())} caracteres). Minimo: {min_text_len}."

    # 3. URL
    safe, msg = is_safe_url(item.url, allowed_domains=allowed_domains)
    if not safe:
        return False, f"URL invalida ou insegura: {msg}"

    # 4. Fonte
    if not item.fonte or not item.fonte.strip():
        return False, "Identificador de fonte ausente."

    # 5. Content Hash (deve ser hex sha256 de 64 caracteres)
    if not item.content_hash or not re.match(r"^[a-f0-9]{64}$", item.content_hash):
        return False, "Hash de conteudo ausente ou em formato diferente de SHA-256."

    # 6. Data de publicacao (pode ser None, mas se presente deve estar no formato ISO)
    if item.data_publicacao is not None:
        if not isinstance(item.data_publicacao, str) or len(item.data_publicacao) < 10:
            return False, "Data de publicacao em formato incompativel com ISO 8601."

    return True, None

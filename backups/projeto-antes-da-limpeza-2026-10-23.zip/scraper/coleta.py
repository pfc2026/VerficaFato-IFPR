"""Ponto de entrada e orquestrador principal do pipeline de coleta de noticias.

Uso via linha de comando:
    python scraper/coleta.py --source g1_parana --limit 5
    python scraper/coleta.py --all --limit 10
    python scraper/coleta.py --no-mongo
"""

import argparse
from datetime import datetime, timezone
import logging
from pathlib import Path
import sys
import time
from typing import Dict, List, Optional

# Garante que a raiz do projeto esteja no sys.path para execucao direta (ex: python scraper/coleta.py)
_CURRENT_DIR = Path(__file__).resolve().parent
_ROOT_DIR = _CURRENT_DIR.parent
if str(_ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(_ROOT_DIR))

try:
    from scraper.collectors import HttpCollector, SeleniumCollector
    from scraper.config import SOURCES, ScraperSettings, SourceConfig
    from scraper.deduplicator import Deduplicator
    from scraper.extractors import NewsExtractor
    from scraper.models import NewsItem
    from scraper.normalizers import normalize_text, normalize_url
    from scraper.storage import StorageManager
    from scraper.validators import is_safe_url, validate_news_item
except ImportError:
    from .collectors import HttpCollector, SeleniumCollector
    from .config import SOURCES, ScraperSettings, SourceConfig
    from .deduplicator import Deduplicator
    from .extractors import NewsExtractor
    from .models import NewsItem
    from .normalizers import normalize_text, normalize_url
    from .storage import StorageManager
    from .validators import is_safe_url, validate_news_item


# Configuracao de logging estruturado
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] [%(name)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("scraper.coleta")


class PipelineMetrics:
    """Contabiliza metricas e estatisticas da execucao do coletor."""

    def __init__(self):
        self.sources_processed: int = 0
        self.links_discovered: int = 0
        self.pages_fetched: int = 0
        self.items_extracted: int = 0
        self.items_valid: int = 0
        self.items_rejected: int = 0
        self.duplicates_ignored: int = 0
        self.files_persisted: int = 0
        self.mongo_persisted: int = 0
        self.errors_count: int = 0

    def summary(self) -> Dict[str, int]:
        return {
            "fontes_processadas": self.sources_processed,
            "links_descobertos": self.links_discovered,
            "paginas_coletadas": self.pages_fetched,
            "itens_extraidos": self.items_extracted,
            "itens_validos": self.items_valid,
            "itens_rejeitados": self.items_rejected,
            "duplicatas_ignoradas": self.duplicates_ignored,
            "registros_arquivos": self.files_persisted,
            "registros_mongodb": self.mongo_persisted,
            "erros_operacionais": self.errors_count,
        }


def collect_source(
    source_cfg: SourceConfig,
    settings: ScraperSettings,
    http_collector: HttpCollector,
    selenium_collector: Optional[SeleniumCollector],
    deduplicator: Deduplicator,
    metrics: PipelineMetrics,
    max_items: Optional[int] = None,
) -> List[NewsItem]:
    """Executa a coleta completa para uma unica fonte configurada."""
    logger.info("Iniciando coleta da fonte: %s (%s)", source_cfg.display_name, source_cfg.start_url)
    items_coletados: List[NewsItem] = []
    limite = max_items if max_items is not None else source_cfg.max_articles

    # 1. Obtem pagina inicial ou listagem de links
    sucesso, html_capa, status, final_url = http_collector.fetch(
        source_cfg.start_url,
        allowed_domains=source_cfg.allowed_domains,
    )
    if not sucesso:
        logger.error("Falha ao obter pagina inicial de %s (status %d): %s", source_cfg.name, status, html_capa)
        metrics.errors_count += 1
        return items_coletados

    # 2. Extrai links de noticias da pagina de capa
    extractor_capa = NewsExtractor.from_html(html_capa, base_url=final_url or source_cfg.start_url)
    links_artigos = extractor_capa.extract_links(
        link_selector=source_cfg.link_selector,
        allowed_domains=source_cfg.allowed_domains,
        url_pattern=source_cfg.url_pattern,
    )

    metrics.links_discovered += len(links_artigos)
    logger.info("Fonte '%s': %d links de noticias identificados.", source_cfg.name, len(links_artigos))

    # 3. Itera sobre cada link coletando os dados do artigo
    artigos_processados = 0
    for url_artigo in links_artigos:
        if artigos_processados >= limite:
            logger.info("Limite de %d artigos atingido para '%s'.", limite, source_cfg.name)
            break

        # Deduplicacao previa por URL
        if deduplicator.is_duplicate(url_artigo):
            metrics.duplicates_ignored += 1
            logger.debug("URL ja processada anteriormente, ignorando: %s", url_artigo)
            continue

        # Cortesia de rede entre chamadas
        if settings.request_delay_seconds > 0:
            time.sleep(settings.request_delay_seconds)

        # 4. Obtem o conteudo do artigo (HTTP ou Selenium)
        html_artigo = ""
        url_final_artigo = url_artigo
        if source_cfg.use_selenium and selenium_collector:
            sucesso_artigo, html_artigo, url_final_artigo = selenium_collector.fetch(
                url_artigo,
                wait_selector=source_cfg.title_selector,
                allowed_domains=source_cfg.allowed_domains,
            )
        else:
            sucesso_artigo, html_artigo, status_artigo, url_final_artigo = http_collector.fetch(
                url_artigo,
                allowed_domains=source_cfg.allowed_domains,
            )

        if not sucesso_artigo or not html_artigo:
            logger.warning("Falha ao obter noticia [%s]: %s", url_artigo, html_artigo)
            metrics.errors_count += 1
            continue

        metrics.pages_fetched += 1

        # 5. Extrai campos do artigo
        extractor_artigo = NewsExtractor.from_html(html_artigo, base_url=url_final_artigo or url_artigo)
        titulo = extractor_artigo.extract_title(custom_selector=source_cfg.title_selector)
        texto = extractor_artigo.extract_text(custom_selector=source_cfg.text_selector)
        data_publicacao = extractor_artigo.extract_date(custom_selector=source_cfg.date_selector)

        metrics.items_extracted += 1

        # 6. Constroi o modelo NewsItem com campos em portugues
        item = NewsItem.build(
            titulo=titulo,
            texto=texto,
            url=url_final_artigo or url_artigo,
            fonte=source_cfg.name,
            data_publicacao=data_publicacao,
        )

        # 7. Valida o contrato de dados estrito
        valido, motivo_rejeicao = validate_news_item(
            item,
            allowed_domains=source_cfg.allowed_domains,
        )
        if not valido:
            metrics.items_rejected += 1
            logger.warning("Artigo rejeitado por validacao [%s]: %s", url_artigo, motivo_rejeicao)
            continue

        # 8. Deduplicacao por hash de conteudo
        if deduplicator.is_duplicate(item.url, item.content_hash):
            metrics.duplicates_ignored += 1
            logger.info("Conteudo duplicado detectado via hash [%s]. Ignorando.", item.url)
            continue

        # Marca como processado
        deduplicator.mark(item.url, item.content_hash)
        items_coletados.append(item)
        metrics.items_valid += 1
        artigos_processados += 1
        logger.info("Artigo coletado com sucesso [%s]: '%s' (%s)", source_cfg.name, item.titulo[:60], item.data_publicacao or "sem data")

    metrics.sources_processed += 1
    return items_coletados


def run_pipeline(
    source_name: Optional[str] = None,
    limit: Optional[int] = None,
    output_dir: Optional[Path] = None,
    enable_mongo: bool = True,
    enable_selenium: bool = False,
) -> int:
    """Executa o pipeline completo de coleta, validacao e persistencia."""
    settings = ScraperSettings()
    if output_dir:
        settings.output_dir = Path(output_dir)
        settings.output_json_path = settings.output_dir / "noticias.json"

    metrics = PipelineMetrics()
    deduplicator = Deduplicator()

    # Pre-carrega itens persistidos para garantir idempotencia a partir de data/noticias.json
    json_path = settings.output_json_path
    if json_path.exists():
        try:
            import json
            with open(json_path, "r", encoding="utf-8") as f:
                dados = json.load(f)
                if isinstance(dados, list):
                    for d in dados:
                        if isinstance(d, dict) and "url" in d:
                            deduplicator.mark(d["url"], d.get("content_hash"))
        except Exception:
            pass

    # Determina fontes a serem executadas
    if source_name and source_name != "all":
        if source_name not in SOURCES:
            logger.error("Fonte desconhecida: '%s'. Fontes disponiveis: %s", source_name, list(SOURCES.keys()))
            return 1
        fontes_selecionadas = [SOURCES[source_name]]
    else:
        fontes_selecionadas = [s for s in SOURCES.values() if s.enabled]

    http_collector = HttpCollector(
        user_agent=settings.user_agent,
        timeout=settings.request_timeout,
        max_retries=settings.max_retries,
        backoff_factor=settings.backoff_factor,
    )

    selenium_collector: Optional[SeleniumCollector] = None
    precisa_selenium = enable_selenium or any(s.use_selenium for s in fontes_selecionadas)
    if precisa_selenium:
        try:
            selenium_collector = SeleniumCollector(
                user_agent=settings.user_agent,
                headless=settings.headless_selenium,
            )
        except Exception as exc:
            logger.warning("Nao foi possivel inicializar Selenium: %s. Coleta prosseguira via HTTP.", exc)
            selenium_collector = None

    todos_itens: List[NewsItem] = []

    try:
        for fonte in fontes_selecionadas:
            try:
                itens = collect_source(
                    source_cfg=fonte,
                    settings=settings,
                    http_collector=http_collector,
                    selenium_collector=selenium_collector,
                    deduplicator=deduplicator,
                    metrics=metrics,
                    max_items=limit,
                )
                todos_itens.extend(itens)
            except Exception as exc:
                logger.error("Erro isolado na fonte '%s': %s", fonte.name, exc, exc_info=True)
                metrics.errors_count += 1
                continue

        # Persistencia dos novos itens
        if todos_itens:
            StorageManager.ensure_dir(settings.output_dir)
            json_file = settings.output_json_path
            jsonl_file = settings.output_dir / "noticias.jsonl"
            csv_file = settings.output_dir / "noticias.csv"

            # Grava no destino padrão data/noticias.json com escrita atômica
            StorageManager.export_json(todos_itens, json_file)
            StorageManager.export_jsonl(todos_itens, jsonl_file)
            StorageManager.export_csv(todos_itens, csv_file)
            metrics.files_persisted = len(todos_itens)

            # Persistencia no MongoDB quando aplicavel
            if enable_mongo and settings.mongo_uri:
                inseridos, duplicados = StorageManager.save_to_mongodb(
                    records=todos_itens,
                    mongo_uri=settings.mongo_uri,
                    db_name=settings.mongo_db_name,
                    collection_name=settings.mongo_collection,
                )
                metrics.mongo_persisted = inseridos
            elif enable_mongo and not settings.mongo_uri:
                logger.info("Persistencia MongoDB nao acionada: MONGO_URI ausente no ambiente.")
        else:
            logger.info("Nenhum novo registro coletado para persistencia nesta execucao.")

    finally:
        http_collector.close()
        if selenium_collector:
            selenium_collector.close()

    # Exibe resumo das metricas
    resumo = metrics.summary()
    logger.info("====== RESUMO DA EXECUCAO DO SCRAPER ======")
    for k, v in resumo.items():
        logger.info("  %s: %d", k, v)
    logger.info("===========================================")

    return 0


def main():
    parser = argparse.ArgumentParser(
        description="Coletor de Noticias e Documentos Regionais — VerificaFato (IFPR)",
    )
    parser.add_argument(
        "--source",
        type=str,
        default="all",
        help=f"Fonte especifica para coleta ou 'all'. Opcoes: {', '.join(SOURCES.keys())}, all",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=None,
        help="Limite de noticias a coletar por fonte (padrao: configuracao da fonte)",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default=None,
        help="Diretorio para gravacao dos arquivos JSON, JSONL e CSV (padrao: data/)",
    )
    parser.add_argument(
        "--no-mongo",
        action="store_true",
        help="Desabilita gravacao no MongoDB mesmo se MONGO_URI estiver configurada",
    )
    parser.add_argument(
        "--selenium",
        action="store_true",
        help="Habilita suporte ao Selenium para fontes dinamicas",
    )

    args = parser.parse_args()

    out_dir = Path(args.output_dir) if args.output_dir else None
    exit_code = run_pipeline(
        source_name=args.source,
        limit=args.limit,
        output_dir=out_dir,
        enable_mongo=not args.no_mongo,
        enable_selenium=args.selenium,
    )
    sys.exit(exit_code)


if __name__ == "__main__":
    main()

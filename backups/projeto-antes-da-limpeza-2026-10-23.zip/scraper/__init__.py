"""Modulo de Coleta de Dados e Web Scraping do VerificaFato Regional (IFPR).

Meta 1: Coleta automatizada, normalizacao, validacao, deduplicacao e persistencia
de noticias de portais jornalisticos regionais.
"""

__version__ = "1.0.0"

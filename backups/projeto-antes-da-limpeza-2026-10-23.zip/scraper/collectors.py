"""Coletores de paginas web: HTTP padrao com retries e Selenium para renderizacao dinamica."""

import logging
import random
import time
from typing import Dict, List, Optional, Tuple
from urllib.parse import urljoin, urlparse
from urllib.robotparser import RobotFileParser

import requests
from requests.adapters import HTTPAdapter

from .validators import is_safe_url

logger = logging.getLogger("scraper.collectors")

DEFAULT_USER_AGENT = (
    "VerificaFato-Bot/1.0 (+https://ifpr.edu.br; pesquisa academica sobre desinformacao; contato@verificafato.ifpr.edu.br)"
)


class RobotsChecker:
    """Consulta e armazena em cache regras de robots.txt por dominio."""

    def __init__(self, user_agent: str = DEFAULT_USER_AGENT, timeout: int = 5):
        self.user_agent = user_agent
        self.timeout = timeout
        self._cache: Dict[str, Optional[RobotFileParser]] = {}

    def is_allowed(self, url: str) -> bool:
        """Verifica se a URL tem permissao de acesso conforme o robots.txt do dominio."""
        parsed = urlparse(url)
        if not parsed.scheme or not parsed.netloc:
            return True

        dominio_base = f"{parsed.scheme}://{parsed.netloc}"
        if dominio_base not in self._cache:
            robots_url = urljoin(dominio_base, "/robots.txt")
            parser = RobotFileParser()
            parser.set_url(robots_url)
            try:
                # Carrega robots.txt com timeout razoavel
                response = requests.get(
                    robots_url,
                    headers={"User-Agent": self.user_agent},
                    timeout=self.timeout,
                )
                if response.status_code == 200:
                    parser.parse(response.text.splitlines())
                    self._cache[dominio_base] = parser
                elif response.status_code in (401, 403):
                    # Acesso restrito ao robots.txt indica cautela
                    self._cache[dominio_base] = None
                else:
                    # 404 indica ausencia de restricoes explicitas
                    self._cache[dominio_base] = parser
            except Exception as exc:
                logger.debug("Nao foi possivel carregar robots.txt de %s: %s", dominio_base, exc)
                self._cache[dominio_base] = parser

        parser = self._cache.get(dominio_base)
        if parser is None:
            return False
        try:
            return parser.can_fetch(self.user_agent, url)
        except Exception:
            return True


class HttpCollector:
    """Cliente HTTP com gerenciamento de sessao, retries com backoff exponencial e timeouts."""

    def __init__(
        self,
        user_agent: str = DEFAULT_USER_AGENT,
        timeout: Tuple[float, float] = (5.0, 15.0),
        max_retries: int = 3,
        backoff_factor: float = 1.0,
        verify_ssl: bool = True,
    ):
        self.user_agent = user_agent
        self.timeout = timeout
        self.max_retries = max_retries
        self.backoff_factor = backoff_factor
        self.verify_ssl = verify_ssl
        self.session = requests.Session()
        self.session.headers.update(
            {
                "User-Agent": self.user_agent,
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
            }
        )
        self.robots_checker = RobotsChecker(user_agent=self.user_agent)

    def fetch(
        self,
        url: str,
        allowed_domains: Optional[List[str]] = None,
        respect_robots: bool = True,
    ) -> Tuple[bool, str, int, Optional[str]]:
        """Realiza a requisicao HTTP com validacao de seguranca e retry limitado.

        Retorna:
            (sucesso, conteudo_html_ou_mensagem_erro, status_code, url_final)
        """
        # 1. Valida se a URL e segura (evita SSRF)
        segura, msg_seguranca = is_safe_url(url, allowed_domains=allowed_domains)
        if not segura:
            logger.warning("Requisicao bloqueada por seguranca [%s]: %s", url, msg_seguranca)
            return False, msg_seguranca, 0, None

        # 2. Respeito ao robots.txt
        if respect_robots and not self.robots_checker.is_allowed(url):
            logger.info("Acesso impedido pelo robots.txt: %s", url)
            return False, "Acesso proibido por robots.txt da fonte.", 403, None

        tentativas = 0
        while tentativas <= self.max_retries:
            try:
                response = self.session.get(
                    url,
                    timeout=self.timeout,
                    verify=self.verify_ssl,
                    allow_redirects=True,
                )

                url_final = response.url
                # Valida se o destino final de eventuais redirecionamentos permanece em dominio permitido
                segura_final, msg_final = is_safe_url(url_final, allowed_domains=allowed_domains)
                if not segura_final:
                    logger.warning("Redirecionamento para destino nao autorizado [%s]: %s", url_final, msg_final)
                    return False, f"Redirecionamento bloqueado: {msg_final}", response.status_code, url_final

                # Sucesso HTTP
                if response.status_code == 200:
                    # Garante decodificacao de caracteres
                    if response.encoding is None or response.encoding == "ISO-8859-1":
                        response.encoding = response.apparent_encoding or "utf-8"
                    return True, response.text, 200, url_final

                # Erros de cliente permanentes (4xx exceto 429) nao devem sofrer retries
                if 400 <= response.status_code < 500 and response.status_code != 429:
                    logger.warning("Erro HTTP permanente %d em %s", response.status_code, url)
                    return False, f"Resposta HTTP {response.status_code}", response.status_code, url_final

                # Erros transitorios (5xx ou 429 Too Many Requests)
                if response.status_code == 429 or response.status_code >= 500:
                    retry_after = response.headers.get("Retry-After")
                    espera = None
                    if retry_after and retry_after.isdigit():
                        espera = min(float(retry_after), 30.0)

                    tentativas += 1
                    if tentativas > self.max_retries:
                        return False, f"Limite de tentativas excedido com status {response.status_code}", response.status_code, url_final

                    if espera is None:
                        # Backoff exponencial com jitter
                        espera = self.backoff_factor * (2 ** (tentativas - 1)) + random.uniform(0.1, 0.5)

                    logger.info("Status %d recebido em %s. Aguardando %.2fs antes de retry (%d/%d)...",
                                response.status_code, url, espera, tentativas, self.max_retries)
                    time.sleep(espera)
                    continue

                return False, f"Status HTTP inesperado: {response.status_code}", response.status_code, url_final

            except (requests.exceptions.Timeout, requests.exceptions.ConnectionError) as exc:
                tentativas += 1
                if tentativas > self.max_retries:
                    logger.error("Falha de rede definitiva em %s: %s", url, exc)
                    return False, f"Erro de conexao/timeout apos {self.max_retries} tentativas: {exc}", 0, None

                espera = self.backoff_factor * (2 ** (tentativas - 1)) + random.uniform(0.1, 0.5)
                logger.warning("Erro transitorio (%s) em %s. Nova tentativa em %.2fs (%d/%d)...",
                               type(exc).__name__, url, espera, tentativas, self.max_retries)
                time.sleep(espera)

            except Exception as exc:
                logger.error("Erro inesperado durante coleta HTTP de %s: %s", url, exc)
                return False, f"Erro inesperado: {exc}", 0, None

        return False, "Falha de coleta nao resolvida.", 0, None

    def close(self):
        """Encerra a sessao e libera os sockets de conexao."""
        try:
            self.session.close()
        except Exception:
            pass


class SeleniumCollector:
    """Coletor com navegador headless baseado em Selenium para fontes dinamicas com renderizacao JS."""

    def __init__(
        self,
        user_agent: str = DEFAULT_USER_AGENT,
        page_load_timeout: int = 20,
        headless: bool = True,
    ):
        self.user_agent = user_agent
        self.page_load_timeout = page_load_timeout
        self.headless = headless
        self._driver = None

    def _init_driver(self):
        """Inicializa a instancia do WebDriver do Chrome de forma segura."""
        if self._driver is not None:
            return self._driver

        from selenium import webdriver
        from selenium.webdriver.chrome.options import Options
        from selenium.webdriver.chrome.service import Service
        from webdriver_manager.chrome import ChromeDriverManager

        options = Options()
        if self.headless:
            options.add_argument("--headless=new")
        options.add_argument("--disable-gpu")
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument(f"--user-agent={self.user_agent}")
        options.add_argument("--blink-settings=imagesEnabled=false")
        options.add_argument("--disable-extensions")

        service = Service(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=service, options=options)
        driver.set_page_load_timeout(self.page_load_timeout)
        self._driver = driver
        return self._driver

    def fetch(
        self,
        url: str,
        wait_selector: Optional[str] = None,
        wait_timeout: int = 10,
        allowed_domains: Optional[List[str]] = None,
    ) -> Tuple[bool, str, Optional[str]]:
        """Abre a pagina no navegador headless, aguarda o elemento e retorna o HTML renderizado."""
        segura, msg = is_safe_url(url, allowed_domains=allowed_domains)
        if not segura:
            logger.warning("URL bloqueada no Selenium: %s (%s)", url, msg)
            return False, msg, None

        try:
            driver = self._init_driver()
            driver.get(url)

            if wait_selector:
                from selenium.webdriver.common.by import By
                from selenium.webdriver.support import expected_conditions as EC
                from selenium.webdriver.support.ui import WebDriverWait

                WebDriverWait(driver, wait_timeout).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, wait_selector))
                )

            final_url = driver.current_url
            html = driver.page_source
            return True, html, final_url

        except Exception as exc:
            logger.error("Falha na renderizacao com Selenium em %s: %s", url, exc)
            return False, f"Erro no Selenium: {exc}", None

    def close(self):
        """Garante o encerramento do processo do navegador."""
        if self._driver is not None:
            try:
                self._driver.quit()
            except Exception as exc:
                logger.debug("Excecao ao fechar Selenium driver: %s", exc)
            finally:
                self._driver = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

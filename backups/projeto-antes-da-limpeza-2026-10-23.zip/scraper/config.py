"""Configuracao centralizada de fontes, parametros de rede e persistencia."""

from dataclasses import dataclass, field
import os
from pathlib import Path
from typing import Dict, List, Optional


def load_env_file(filepath: Path):
    """Carrega variaveis de ambiente de arquivo .env de forma simples sem bibliotecas extras."""
    if not filepath.exists():
        return
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            for line in f:
                linha = line.strip()
                if not linha or linha.startswith("#") or "=" not in linha:
                    continue
                chave, valor = linha.split("=", 1)
                chave = chave.strip()
                valor = valor.strip().strip("'\"")
                if chave not in os.environ:
                    os.environ[chave] = valor
    except Exception:
        pass


# Raiz do repositorio VerificaFato
ROOT_DIR = Path(__file__).resolve().parent.parent
load_env_file(ROOT_DIR / ".env")


@dataclass
class SourceConfig:
    """Configuracao de uma fonte de coleta de noticias ou diario oficial."""

    name: str
    display_name: str
    start_url: str
    allowed_domains: List[str]
    url_pattern: Optional[str] = None
    link_selector: Optional[str] = None
    title_selector: Optional[str] = None
    text_selector: Optional[str] = None
    date_selector: Optional[str] = None
    use_selenium: bool = False
    max_articles: int = 15
    enabled: bool = True


# Catalogo de fontes jornalisticas regionais e orgaos oficiais do Parana
SOURCES: Dict[str, SourceConfig] = {
    "g1_parana": SourceConfig(
        name="g1_parana",
        display_name="G1 Paraná",
        start_url="https://g1.globo.com/pr/",
        allowed_domains=["g1.globo.com", "globo.com"],
        url_pattern=r"g1\.globo\.com/pr/.*noticia",
        link_selector="a.feed-post-link, a[href*='/pr/']",
        title_selector="h1.content-head__title",
        text_selector="article, .mc-body, .content-text",
        date_selector="time[itemprop='datePublished'], time",
        use_selenium=False,
        max_articles=10,
    ),
    "o_parana": SourceConfig(
        name="o_parana",
        display_name="Jornal O Paraná",
        start_url="https://www.oparana.com.br",
        allowed_domains=["oparana.com.br", "www.oparana.com.br"],
        url_pattern=r"oparana\.com\.br/(noticia|parana|cascavel|oeste)",
        link_selector="article a, .entry-title a, a[href*='oparana.com.br']",
        title_selector="h1.entry-title, h1.post-title",
        text_selector="div.entry-content, article",
        date_selector="time.entry-date, .posted-on time",
        use_selenium=False,
        max_articles=10,
    ),
    "gazeta_do_povo": SourceConfig(
        name="gazeta_do_povo",
        display_name="Gazeta do Povo",
        start_url="https://www.gazetadopovo.com.br/parana/",
        allowed_domains=["gazetadopovo.com.br", "www.gazetadopovo.com.br"],
        url_pattern=r"gazetadopovo\.com\.br/parana/.*",
        link_selector="article a, a[href*='/parana/']",
        title_selector="h1.c-title, h1.title",
        text_selector="article, .c-body",
        date_selector="time",
        use_selenium=False,
        max_articles=10,
    ),
    "jornal_de_toledo": SourceConfig(
        name="jornal_de_toledo",
        display_name="Jornal de Toledo",
        start_url="https://www.jornaldetoledo.com.br",
        allowed_domains=["jornaldetoledo.com.br", "www.jornaldetoledo.com.br"],
        url_pattern=r"jornaldetoledo\.com\.br/.*",
        link_selector="article a, .post-title a",
        title_selector="h1.entry-title, h1.post-title",
        text_selector="div.entry-content, article",
        date_selector="time",
        use_selenium=False,
        max_articles=10,
    ),
    "radio_colmeia": SourceConfig(
        name="radio_colmeia",
        display_name="Rádio Colmeia (Cascavel)",
        start_url="https://radiocolmeia.com.br",
        allowed_domains=["radiocolmeia.com.br", "www.radiocolmeia.com.br"],
        url_pattern=r"radiocolmeia\.com\.br/.*",
        link_selector="article a, h2 a, h3 a",
        title_selector="h1.entry-title, h1",
        text_selector="div.entry-content, article",
        date_selector="time",
        use_selenium=False,
        max_articles=10,
    ),
    "radio_cultura_toledo": SourceConfig(
        name="radio_cultura_toledo",
        display_name="Rádio Cultura Toledo",
        start_url="https://www.radioculturatoledo.com.br",
        allowed_domains=["radioculturatoledo.com.br", "www.radioculturatoledo.com.br"],
        url_pattern=r"radioculturatoledo\.com\.br/.*",
        link_selector="article a, .post a, a[href*='noticia']",
        title_selector="h1",
        text_selector="article, .entry-content",
        date_selector="time",
        use_selenium=False,
        max_articles=10,
    ),
}


@dataclass
class ScraperSettings:
    """Parametros gerais de execucao do pipeline de coleta."""

    user_agent: str = (
        "VerificaFato-Bot/1.0 (+https://ifpr.edu.br; pesquisa academica; contato@verificafato.ifpr.edu.br)"
    )
    request_timeout: tuple = (5.0, 15.0)
    request_delay_seconds: float = 1.0
    max_retries: int = 3
    backoff_factor: float = 1.0
    # Destino padrao conforme especificacao da Meta 1: data/noticias.json
    output_dir: Path = ROOT_DIR / "data"
    output_json_path: Path = ROOT_DIR / "data" / "noticias.json"
    mongo_uri: Optional[str] = os.getenv("MONGO_URI")
    mongo_db_name: str = os.getenv("MONGO_DB_NAME", "verificafato")
    mongo_collection: str = os.getenv("MONGO_COLLECTION", "noticias_coletadas")
    headless_selenium: bool = True

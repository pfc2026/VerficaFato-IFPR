"""Mecanismos de persistencia: arquivos JSON (padrao data/noticias.json), JSONL, CSV e MongoDB."""

import csv
import json
import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

from .models import NewsItem

logger = logging.getLogger("scraper.storage")

CSV_FIELDNAMES = [
    "titulo",
    "data_publicacao",
    "texto",
    "url",
    "fonte",
    "coletado_em",
    "content_hash",
]


class StorageManager:
    """Responsavel pela persistencia estruturada e segura de noticias coletadas."""

    @staticmethod
    def ensure_dir(dir_path: Union[str, Path]) -> Path:
        """Garante a existencia do diretorio de saida."""
        path = Path(dir_path)
        path.mkdir(parents=True, exist_ok=True)
        return path

    @classmethod
    def export_json(cls, records: List[NewsItem], filepath: Union[str, Path]) -> int:
        """Exporta com escrita atomica e segura para arquivo JSON formatado em UTF-8."""
        if not records:
            return 0
        dest = Path(filepath)
        cls.ensure_dir(dest.parent)

        existentes: List[Dict[str, Any]] = []
        if dest.exists() and dest.stat().st_size > 0:
            try:
                with open(dest, "r", encoding="utf-8") as f:
                    dados_carregados = json.load(f)
                    if isinstance(dados_carregados, list):
                        existentes = dados_carregados
            except Exception as exc:
                logger.warning("Falha ao ler arquivo JSON existente em %s: %s", dest, exc)

        urls_existentes = {item.get("url") for item in existentes if isinstance(item, dict)}
        novos_adicionados = 0
        for rec in records:
            if rec.url not in urls_existentes:
                existentes.append(rec.to_dict())
                urls_existentes.add(rec.url)
                novos_adicionados += 1

        # Escrita atomica: salva em arquivo temporario e substitui atomicamente
        temp_file = dest.with_suffix(dest.suffix + ".tmp")
        try:
            with open(temp_file, "w", encoding="utf-8") as f:
                json.dump(existentes, f, ensure_ascii=False, indent=2)
            temp_file.replace(dest)
        except Exception as exc:
            if temp_file.exists():
                temp_file.unlink()
            logger.error("Erro na gravacao do JSON em %s: %s", dest, exc)
            raise exc

        logger.info("Gravados %d novos registros (total %d) no JSON: %s", novos_adicionados, len(existentes), dest)
        return novos_adicionados

    @classmethod
    def export_jsonl(cls, records: List[NewsItem], filepath: Union[str, Path]) -> int:
        """Exporta os registros para formato JSON Lines em UTF-8."""
        if not records:
            return 0
        dest = Path(filepath)
        cls.ensure_dir(dest.parent)

        escritos = 0
        with open(dest, "a", encoding="utf-8") as f:
            for item in records:
                linha = json.dumps(item.to_dict(), ensure_ascii=False)
                f.write(linha + "\n")
                escritos += 1

        logger.info("Exportados %d registros para JSONL: %s", escritos, dest)
        return escritos

    @classmethod
    def export_csv(cls, records: List[NewsItem], filepath: Union[str, Path]) -> int:
        """Exporta os registros para arquivo CSV codificado em UTF-8 com BOM."""
        if not records:
            return 0
        dest = Path(filepath)
        cls.ensure_dir(dest.parent)

        arquivo_novo = not dest.exists() or dest.stat().st_size == 0
        escritos = 0

        with open(dest, "a", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=CSV_FIELDNAMES, delimiter=";", quoting=csv.QUOTE_MINIMAL)
            if arquivo_novo:
                writer.writeheader()

            for item in records:
                d = item.to_dict()
                row = {k: ("" if d.get(k) is None else str(d.get(k))) for k in CSV_FIELDNAMES}
                writer.writerow(row)
                escritos += 1

        logger.info("Exportados %d registros para CSV: %s", escritos, dest)
        return escritos

    @classmethod
    def save_to_mongodb(
        cls,
        records: List[NewsItem],
        mongo_uri: Optional[str],
        db_name: str = "verificafato",
        collection_name: str = "noticias_coletadas",
    ) -> Tuple[int, int]:
        """Persiste os registros no MongoDB com garantia de idempotencia por URL."""
        if not records:
            return 0, 0
        if not mongo_uri:
            logger.info("MONGO_URI nao fornecida. Persistencia em MongoDB ignorada.")
            return 0, 0

        try:
            from pymongo import MongoClient, UpdateOne
            from pymongo.errors import PyMongoError
        except ImportError:
            logger.error("Pacote 'pymongo' nao encontrado. Impossivel persistir no banco.")
            return 0, 0

        try:
            client = MongoClient(mongo_uri, serverSelectionTimeoutMS=5000)
            db = client[db_name]
            collection = db[collection_name]

            # Indices para busca eficiente e unicidade
            collection.create_index("url", unique=True)
            collection.create_index("content_hash")
            collection.create_index("fonte")
            collection.create_index("coletado_em")

            operacoes = []
            for item in records:
                doc = item.to_dict()
                operacoes.append(
                    UpdateOne(
                        {"url": item.url},
                        {"$setOnInsert": doc},
                        upsert=True,
                    )
                )

            if operacoes:
                resultado = collection.bulk_write(operacoes, ordered=False)
                inseridos = resultado.upserted_count
                duplicados = len(records) - inseridos
                logger.info(
                    "MongoDB [%s.%s]: %d documentos inseridos, %d preexistentes/ignorados.",
                    db_name, collection_name, inseridos, duplicados,
                )
                client.close()
                return inseridos, duplicados

            client.close()
            return 0, 0

        except PyMongoError as exc:
            logger.error("Falha ao comunicar com MongoDB: %s", exc)
            return 0, 0
        except Exception as exc:
            logger.error("Erro inesperado na gravacao MongoDB: %s", exc)
            return 0, 0

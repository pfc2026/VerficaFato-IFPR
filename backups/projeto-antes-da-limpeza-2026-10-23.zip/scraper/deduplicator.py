"""Mecanismo de deduplicacao de registros e URLs."""

import json
from pathlib import Path
from typing import Optional, Set


class Deduplicator:
    """Gerencia conjuntos de URLs e hashes para prevencao de duplicatas."""

    def __init__(self):
        self.seen_urls: Set[str] = set()
        self.seen_hashes: Set[str] = set()

    def load_from_jsonl(self, filepath: Path) -> int:
        """Carrega URLs e hashes ja persistidos em arquivo JSONL existente."""
        if not filepath.exists():
            return 0
        carregados = 0
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                for line in f:
                    line_clean = line.strip()
                    if not line_clean:
                        continue
                    try:
                        data = json.loads(line_clean)
                        url = data.get("url")
                        chash = data.get("content_hash")
                        if url:
                            self.seen_urls.add(url)
                        if chash:
                            self.seen_hashes.add(chash)
                        carregados += 1
                    except json.JSONDecodeError:
                        continue
        except Exception:
            pass
        return carregados

    def is_duplicate(self, url: str, content_hash: Optional[str] = None) -> bool:
        """Verifica se a URL ou o hash do conteudo ja foram registrados."""
        if url in self.seen_urls:
            return True
        if content_hash and content_hash in self.seen_hashes:
            return True
        return False

    def mark(self, url: str, content_hash: Optional[str] = None):
        """Registra a URL e o hash como processados."""
        self.seen_urls.add(url)
        if content_hash:
            self.seen_hashes.add(content_hash)

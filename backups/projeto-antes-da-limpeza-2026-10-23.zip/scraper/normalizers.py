"""Funcoes de normalizacao de texto, URLs e datas."""

from datetime import datetime, timezone
import re
import unicodedata
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse
from typing import Optional

MESES_PT = {
    "janeiro": 1,
    "fevereiro": 2,
    "marco": 3,
    "março": 3,
    "abril": 4,
    "maio": 5,
    "junho": 6,
    "julho": 7,
    "agosto": 8,
    "setembro": 9,
    "outubro": 10,
    "novembro": 11,
    "dezembro": 12,
}

TRACKING_PARAMS = {
    "utm_source",
    "utm_medium",
    "utm_campaign",
    "utm_term",
    "utm_content",
    "fbclid",
    "gclid",
    "msclkid",
    "ref",
    "referrer",
}


def normalize_text(text: Optional[str]) -> str:
    """Normaliza caracteres Unicode, espacos em branco e quebras de linha."""
    if not text:
        return ""
    # Normaliza caracteres compostos para a forma canonica de compatibilidade
    normalizado = unicodedata.normalize("NFKC", text)
    # Remove caracteres de controle estranhos exceto newline e tab
    normalizado = "".join(
        ch for ch in normalizado if ch in ("\n", "\t") or not unicodedata.category(ch).startswith("C")
    )
    # Uniformiza quebras de linha
    normalizado = normalizado.replace("\r\n", "\n").replace("\r", "\n")
    # Reduz espacos horizontais duplicados
    linhas = [re.sub(r"[ \t]+", " ", linha).strip() for linha in normalizado.split("\n")]
    # Remove quebras de linha excessivas consecutivas
    texto_final = re.sub(r"\n{3,}", "\n\n", "\n".join(linhas))
    return texto_final.strip()


def normalize_url(url: Optional[str]) -> str:
    """Normaliza a URL removendo fragmentos, parametros de rastreamento e uniformizando host."""
    if not url:
        return ""
    parsed = urlparse(url.strip())
    if not parsed.scheme or not parsed.netloc:
        return url.strip()

    scheme = parsed.scheme.lower()
    netloc = parsed.netloc.lower()

    # Filtra parametros de rastreamento da query string
    query_params = parse_qsl(parsed.query, keep_blank_values=True)
    filtered_query = [
        (k, v) for k, v in query_params if k.lower() not in TRACKING_PARAMS
    ]
    new_query = urlencode(filtered_query)

    # Remove trailing slash redundante no final do path se for maior que 1 caractere
    path = parsed.path
    if len(path) > 1 and path.endswith("/"):
        path = path[:-1]

    # Fragmento descartado (#secao)
    return urlunparse((scheme, netloc, path, parsed.params, new_query, ""))


def parse_and_normalize_date(raw_date: Optional[str]) -> Optional[str]:
    """Tenta converter datas de publicacao para ISO 8601.

    Preserva fuso horario quando fornecido. Retorna None caso a informacao
    seja ambigua, invalida ou nao confiavel. Nunca gera datas arbitrarias.
    """
    if not raw_date:
        return None

    texto = raw_date.strip()
    if not texto:
        return None

    # 1. Tentativa: Formato padrao ISO 8601
    try:
        # datetime.fromisoformat aceita formatos com 'Z' ou offset a partir do Python 3.11
        iso_candidato = texto.replace("Z", "+00:00")
        dt = datetime.fromisoformat(iso_candidato)
        return dt.isoformat()
    except (ValueError, TypeError):
        pass

    # 2. Tentativa: Formatos brasileiros com hora (ex: 23/10/2024 14:30:00 ou 23/10/2024 14:30)
    formatos_brasileiros = [
        ("%d/%m/%Y %H:%M:%S", False),
        ("%d/%m/%Y %H:%M", False),
        ("%d/%m/%Y", False),
        ("%d-%m-%Y %H:%M:%S", False),
        ("%d-%m-%Y %H:%M", False),
        ("%d-%m-%Y", False),
        ("%Y/%m/%d %H:%M:%S", False),
        ("%Y-%m-%d %H:%M:%S", False),
        ("%Y-%m-%d", False),
    ]

    for fmt, _ in formatos_brasileiros:
        try:
            dt = datetime.strptime(texto, fmt)
            return dt.isoformat()
        except ValueError:
            continue

    # 3. Tentativa: Texto por extenso em portugues (ex: "23 de outubro de 2024", "23 de outubro de 2024 às 14:30")
    padrao_extenso = re.search(
        r"(\d{1,2})\s+de\s+([a-zA-Zç]+)\s+de\s+(\d{4})(?:.*?(\d{1,2})[h:](\d{2}))?",
        texto.lower(),
    )
    if padrao_extenso:
        dia_s, mes_s, ano_s, hora_s, min_s = padrao_extenso.groups()
        mes_num = MESES_PT.get(mes_s)
        if mes_num:
            try:
                dia = int(dia_s)
                ano = int(ano_s)
                hora = int(hora_s) if hora_s else 0
                minuto = int(min_s) if min_s else 0
                dt = datetime(ano, mes_num, dia, hora, minuto, 0)
                return dt.isoformat()
            except ValueError:
                return None

    return None

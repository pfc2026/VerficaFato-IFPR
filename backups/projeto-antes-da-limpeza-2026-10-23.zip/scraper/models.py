"""Modelos de dados do pipeline de coleta."""

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import hashlib
from typing import Any, Dict, Optional


@dataclass(frozen=True)
class NewsItem:
    """Representa um documento de noticia coletado, validado e normalizado."""

    titulo: str
    texto: str
    data_publicacao: Optional[str]
    url: str
    fonte: str
    coletado_em: str
    content_hash: str

    # Propriedades de compatibilidade para código que utilize termos em inglês
    @property
    def title(self) -> str:
        return self.titulo

    @property
    def text(self) -> str:
        return self.texto

    @property
    def date(self) -> Optional[str]:
        return self.data_publicacao

    @property
    def source(self) -> str:
        return self.fonte

    @property
    def collected_at(self) -> str:
        return self.coletado_em

    @classmethod
    def compute_content_hash(cls, titulo: str, texto: str) -> str:
        """Calcula hash deterministico SHA-256 combinando titulo e texto normalizados."""
        payload = f"{titulo.strip().lower()}|{texto.strip().lower()}".encode("utf-8")
        return hashlib.sha256(payload).hexdigest()

    @classmethod
    def build(
        cls,
        titulo: str,
        texto: str,
        url: str,
        fonte: str,
        data_publicacao: Optional[str] = None,
        coletado_em: Optional[str] = None,
        content_hash: Optional[str] = None,
    ) -> "NewsItem":
        """Fabrica uma instancia de NewsItem com timestamp UTC e hash automaticos se omitidos."""
        utc_now = (
            coletado_em
            if coletado_em
            else datetime.now(timezone.utc).isoformat()
        )
        calculated_hash = (
            content_hash
            if content_hash
            else cls.compute_content_hash(titulo, texto)
        )
        return cls(
            titulo=titulo,
            texto=texto,
            data_publicacao=data_publicacao,
            url=url,
            fonte=fonte,
            coletado_em=utc_now,
            content_hash=calculated_hash,
        )

    def to_dict(self) -> Dict[str, Any]:
        """Converte a instancia para dicionario Python compativel com JSON e MongoDB."""
        return {
            "titulo": self.titulo,
            "data_publicacao": self.data_publicacao,
            "texto": self.texto,
            "url": self.url,
            "fonte": self.fonte,
            "coletado_em": self.coletado_em,
            "content_hash": self.content_hash,
        }

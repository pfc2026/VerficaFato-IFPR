// Compatibilidade de importação; a implementação é compartilhada por todo o backend.
export { verificarNoticia } from './services/fact-check.js';
export { keywordQuery as extrairPalavrasChave } from './services/claims.js';
export { obterConteudoDaUrl } from './services/extraction.js';

const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');

const NoticiaColetadaSchema = new mongoose.Schema(
  {
    titulo: { type: String, required: true, trim: true },
    texto: { type: String, required: true },
    data_publicacao: { type: String, default: null },
    url: { type: String, required: true, unique: true, trim: true },
    fonte: { type: String, required: true, trim: true },
    coletado_em: { type: String, required: true },
    content_hash: { type: String, required: true }
  },
  {
    timestamps: true,
    collection: 'noticias_coletadas'
  }
);

// Cria índice de texto para buscas rápidas em título e texto
NoticiaColetadaSchema.index({ titulo: 'text', texto: 'text' }, { weights: { titulo: 10, texto: 2 }, default_language: 'portuguese' });

/**
 * Busca notícias correspondentes no MongoDB com fallback seguro no arquivo data/noticias.json
 */
NoticiaColetadaSchema.statics.buscarCorrespondentes = async function (textoBusca, urlBusca = '') {
  const correspondentes = [];
  const linkLimpo = (urlBusca || '').trim();

  // 1. Busca por URL exata se houver link
  if (linkLimpo) {
    try {
      const matchUrl = await this.findOne({ url: linkLimpo }).lean();
      if (matchUrl) return [matchUrl];
    } catch (_) {}
  }

  // 2. Busca por termos no MongoDB
  if (textoBusca && textoBusca.trim().length >= 4) {
    const palavras = textoBusca
      .replace(/[^\wÀ-ú\s]/g, ' ')
      .split(/\s+/)
      .filter(p => p.length > 3)
      .slice(0, 8);

    if (palavras.length > 0) {
      try {
        // Tenta primeiro via busca de texto indexada
        const queryTexto = palavras.join(' ');
        const resultadosText = await this.find(
          { $text: { $search: queryTexto } },
          { score: { $meta: 'textScore' } }
        )
          .sort({ score: { $meta: 'textScore' } })
          .limit(3)
          .lean();

        if (resultadosText && resultadosText.length > 0) {
          return resultadosText;
        }
      } catch (_) {
        // Se índice de texto não estiver pronto, tenta via regex com as palavras mais longas
        try {
          const termosRegex = palavras.slice(0, 3).map(p => new RegExp(p, 'i'));
          const resultadosRegex = await this.find({
            $or: [
              { titulo: { $in: termosRegex } },
              { texto: { $in: termosRegex } }
            ]
          }).limit(3).lean();

          if (resultadosRegex && resultadosRegex.length > 0) {
            return resultadosRegex;
          }
        } catch (_) {}
      }
    }
  }

  // 3. Fallback: Lê diretamente do arquivo local data/noticias.json
  try {
    const jsonPath = path.join(__dirname, '..', 'data', 'noticias.json');
    if (fs.existsSync(jsonPath)) {
      const conteudo = JSON.parse(fs.readFileSync(jsonPath, 'utf8'));
      if (Array.isArray(conteudo)) {
        if (linkLimpo) {
          const match = conteudo.find(n => n.url === linkLimpo);
          if (match) return [match];
        }

        const termos = (textoBusca || '')
          .toLowerCase()
          .replace(/[^\wÀ-ú\s]/g, ' ')
          .split(/\s+/)
          .filter(p => p.length > 3);

        const pontuados = conteudo.map(noticia => {
          let score = 0;
          const tit = (noticia.titulo || '').toLowerCase();
          const txt = (noticia.texto || '').toLowerCase();
          termos.forEach(t => {
            if (tit.includes(t)) score += 5;
            if (txt.includes(t)) score += 1;
          });
          return { noticia, score };
        });

        const relevantes = pontuados
          .filter(p => p.score >= 4)
          .sort((a, b) => b.score - a.score)
          .slice(0, 3)
          .map(p => p.noticia);

        if (relevantes.length > 0) return relevantes;
      }
    }
  } catch (_) {}

  return correspondentes;
};

module.exports = mongoose.model('NoticiaColetada', NoticiaColetadaSchema);

"""Testes automatizados unitarios do modulo de web scraping e pipeline ETL."""

import csv
import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import requests

from scraper.collectors import HttpCollector, SeleniumCollector
from scraper.config import ScraperSettings, SourceConfig
from scraper.deduplicator import Deduplicator
from scraper.extractors import NewsExtractor
from scraper.models import NewsItem
from scraper.normalizers import normalize_text, normalize_url, parse_and_normalize_date
from scraper.storage import StorageManager
from scraper.validators import is_safe_url, validate_news_item


# ── Fixtures e HTMLs representativos para testes locais ────────────────────

HTML_NOTICIA_COMPLETA = """
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Título da Notícia Teste - Portal Regional</title>
    <meta property="og:title" content="Título Canônico da Notícia">
    <meta property="article:published_time" content="2024-10-23T14:30:00-03:00">
</head>
<body>
    <header><nav><a href="/">Início</a><a href="/politica">Política</a></nav></header>
    <article>
        <h1>Título Canônico da Notícia</h1>
        <time datetime="2024-10-23T14:30:00-03:00">23 de outubro de 2024</time>
        <div class="entry-content">
            <p>O Instituto Federal do Paraná (IFPR) anunciou uma nova iniciativa acadêmica focada no combate à desinformação.</p>
            <p>A pesquisa regional visa analisar os efeitos de notícias falsas e fornecer ferramentas de verificação para a comunidade.</p>
        </div>
        <div class="social-share">Compartilhe no WhatsApp</div>
    </article>
    <aside class="anuncio">Propaganda aqui</aside>
    <footer>Rodapé institucional</footer>
</body>
</html>
"""

HTML_NOTICIA_JSON_LD = """
<!DOCTYPE html>
<html>
<head>
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "NewsArticle",
        "headline": "Prefeitura de Cascavel entrega novas obras viárias",
        "datePublished": "2024-05-15T10:00:00Z"
    }
    </script>
</head>
<body>
    <article>
        <h1>Prefeitura de Cascavel entrega novas obras viárias</h1>
        <p>As obras de infraestrutura beneficiarão mais de cinquenta mil moradores do município nesta primeira fase.</p>
        <p>A cerimônia de inauguração contou com a presença de autoridades locais e membros da sociedade civil.</p>
    </article>
</body>
</html>
"""

HTML_NOTICIA_LAYOUT_ALTERNATIVO = """
<!DOCTYPE html>
<html>
<head>
    <title>Notícia em Layout Alternativo</title>
</head>
<body>
    <div class="post-header">
        <h1 class="post-title">Campus IFPR promove seminário regional</h1>
        <span class="posted-on">10/08/2024 09:15</span>
    </div>
    <div class="post-content">
        <p>O evento reunirá pesquisadores de várias cidades do Paraná para debater tecnologias educacionais.</p>
        <p>As inscrições estão abertas e podem ser realizadas gratuitamente até o final da próxima semana.</p>
    </div>
</body>
</html>
"""

HTML_NOTICIA_SEM_DATA = """
<!DOCTYPE html>
<html>
<body>
    <article>
        <h1>Notícia Sem Informação de Data Publicada</h1>
        <p>Este artigo não contém nenhuma marcação temporal ou elemento time com data compreensível.</p>
        <p>O sistema deve registrar a data de publicação estritamente como nula para não inventar fatos.</p>
    </article>
</body>
</html>
"""


# ── 1. Extração dos quatro campos obrigatórios ──────────────────────────────

def test_extracao_quatro_campos_obrigatorios():
    url = "https://www.oparana.com.br/noticia/teste-1"
    extractor = NewsExtractor.from_html(HTML_NOTICIA_COMPLETA, base_url=url)

    titulo = extractor.extract_title()
    data = extractor.extract_date()
    texto = extractor.extract_text()

    item = NewsItem.build(
        titulo=titulo,
        texto=texto,
        url=url,
        fonte="o_parana",
        data_publicacao=data,
    )

    # 4 campos obrigatórios: titulo, texto, data_publicacao e url
    assert item.titulo == "Título Canônico da Notícia"
    assert "Instituto Federal do Paraná" in item.texto
    assert item.data_publicacao == "2024-10-23T14:30:00-03:00"
    assert item.url == url

    # Validação do contrato
    valido, erro = validate_news_item(item, allowed_domains=["oparana.com.br"])
    assert valido is True
    assert erro is None


# ── 2. Variações de layout HTML ─────────────────────────────────────────────

def test_extracao_variacoes_layout_html():
    # Variação 1: JSON-LD
    ext_json_ld = NewsExtractor.from_html(HTML_NOTICIA_JSON_LD, base_url="https://cascavel.pr.gov.br/noticia")
    assert "Prefeitura de Cascavel" in ext_json_ld.extract_title()
    assert "2024-05-15" in ext_json_ld.extract_date()
    assert "infraestrutura beneficiarão" in ext_json_ld.extract_text()

    # Variação 2: Layout alternativo com classes post-title e post-content
    ext_alt = NewsExtractor.from_html(HTML_NOTICIA_LAYOUT_ALTERNATIVO, base_url="https://jornaldetoledo.com.br/post")
    assert ext_alt.extract_title() == "Campus IFPR promove seminário regional"
    assert "2024-08-10" in ext_alt.extract_date()
    assert "evento reunirá pesquisadores" in ext_alt.extract_text()


# ── 3. Datas ausentes ou inválidas ──────────────────────────────────────────

def test_datas_ausentes_ou_invalidas():
    ext_sem_data = NewsExtractor.from_html(HTML_NOTICIA_SEM_DATA, base_url="https://g1.globo.com/pr/1")
    data_extraida = ext_sem_data.extract_date()
    assert data_extraida is None

    # Normalizador direto com lixo ou dados inválidos
    assert parse_and_normalize_date("data invalida") is None
    assert parse_and_normalize_date("") is None
    assert parse_and_normalize_date(None) is None

    # O item gerado deve conter data_publicacao=None
    item = NewsItem.build(
        titulo="Título Válido",
        texto="Texto da matéria longo o suficiente para passar no validador.",
        url="https://g1.globo.com/pr/1",
        fonte="g1_parana",
        data_publicacao=data_extraida,
    )
    assert item.data_publicacao is None
    d = item.to_dict()
    assert d["data_publicacao"] is None


# ── 4. URLs inválidas e domínios não autorizados ────────────────────────────

def test_urls_invalidas_e_dominios_nao_autorizados():
    # Dominio não autorizado
    valido, msg = is_safe_url("https://malicioso.com/noticia", allowed_domains=["g1.globo.com"])
    assert valido is False
    assert "nao consta na lista de dominios autorizados" in msg

    # SSRF / Loopback / IP Privado
    bloqueios = [
        "http://localhost:8000/api",
        "http://127.0.0.1:3000/segredo",
        "http://10.0.0.1/admin",
        "http://192.168.0.1/roteador",
        "http://169.254.169.254/metadata",
        "ftp://g1.globo.com/arquivo",
    ]
    for url in bloqueios:
        v, _ = is_safe_url(url)
        assert v is False, f"URL deveria ser bloqueada: {url}"


# ── 5. Duplicação de notícias ──────────────────────────────────────────────

def test_duplicacao_de_noticias():
    dedup = Deduplicator()
    url = "https://g1.globo.com/pr/materia-1"
    hash_conteudo = NewsItem.compute_content_hash("Notícia 1", "Texto longo 1")

    assert dedup.is_duplicate(url, hash_conteudo) is False
    dedup.mark(url, hash_conteudo)
    assert dedup.is_duplicate(url, hash_conteudo) is True

    # Mesma notícia com URL ligeiramente alterada mas mesmo conteúdo
    url_copia = "https://g1.globo.com/pr/materia-1-republicada"
    assert dedup.is_duplicate(url_copia, hash_conteudo) is True


# ── 6. Timeouts e falhas HTTP ──────────────────────────────────────────────

def test_timeouts_e_falhas_http():
    collector = HttpCollector(max_retries=2, backoff_factor=0.01)

    # Simula timeout de conexão
    with patch.object(collector.session, "get", side_effect=requests.exceptions.Timeout("Timeout")):
        with patch.object(collector.robots_checker, "is_allowed", return_value=True):
            sucesso, msg, status, _ = collector.fetch("https://g1.globo.com/pr/teste")
            assert sucesso is False
            assert status == 0
            assert "Timeout" in msg

    # Simula erro 404 permanente (não deve fazer retry)
    mock_404 = MagicMock()
    mock_404.status_code = 404
    mock_404.url = "https://g1.globo.com/pr/nao-existe"
    with patch.object(collector.session, "get", return_value=mock_404) as mock_get:
        with patch.object(collector.robots_checker, "is_allowed", return_value=True):
            sucesso, msg, status, _ = collector.fetch("https://g1.globo.com/pr/nao-existe")
            assert sucesso is False
            assert status == 404
            assert mock_get.call_count == 1

    collector.close()


# ── 7. Exportação para data/noticias.json ────────────────────────────────────

def test_exportacao_data_noticias_json(tmp_path: Path):
    json_path = tmp_path / "data" / "noticias.json"

    item1 = NewsItem.build(
        titulo="Notícia Regional 1",
        texto="Texto da matéria de teste com acentuação e caracteres especiais: atenção, maçã, João.",
        url="https://www.oparana.com.br/noticia/1",
        fonte="o_parana",
        data_publicacao="2024-10-23T10:00:00-03:00",
    )
    item2 = NewsItem.build(
        titulo="Notícia Regional 2",
        texto="Segundo texto jornalístico para validação do formato JSON estruturado.",
        url="https://www.oparana.com.br/noticia/2",
        fonte="o_parana",
        data_publicacao=None,
    )

    novos = StorageManager.export_json([item1, item2], json_path)
    assert novos == 2
    assert json_path.exists()

    # Verifica integridade do JSON gerado
    with open(json_path, "r", encoding="utf-8") as f:
        dados = json.load(f)
        assert isinstance(dados, list)
        assert len(dados) == 2
        assert dados[0]["titulo"] == "Notícia Regional 1"
        assert "atenção, maçã, João" in dados[0]["texto"]
        assert dados[0]["data_publicacao"] == "2024-10-23T10:00:00-03:00"
        assert dados[1]["data_publicacao"] is None

    # Idempotência: reexportar os mesmos itens não duplica
    novos_segunda = StorageManager.export_json([item1], json_path)
    assert novos_segunda == 0


# ── 8. Falhas de persistência ──────────────────────────────────────────────

def test_falhas_de_persistencia(tmp_path: Path):
    # Simula erro de permissão ou caminho inválido
    caminho_invalido = tmp_path / "diretorio_arquivo"
    caminho_invalido.write_text("bloqueio")

    # Tentar gravar como se fosse diretório gera exceção tratada
    json_bloqueado = caminho_invalido / "sub" / "noticias.json"
    item = NewsItem.build(
        titulo="Teste Falha",
        texto="Texto de teste para validação de erro.",
        url="https://g1.globo.com/pr/1",
        fonte="g1_parana",
    )

    with pytest.raises(Exception):
        StorageManager.export_json([item], json_bloqueado)


# ── 9. Continuidade da coleta após falhas isoladas ──────────────────────────

def test_continuidade_coleta_apos_falha_isolada():
    from scraper.coleta import PipelineMetrics, collect_source

    source_cfg = SourceConfig(
        name="teste_continuidade",
        display_name="Teste Continuidade",
        start_url="https://portalteste.com.br",
        allowed_domains=["portalteste.com.br"],
    )
    settings = ScraperSettings(request_delay_seconds=0)
    metrics = PipelineMetrics()
    dedup = Deduplicator()

    # Mock do coletor HTTP: capa ok com 2 links; primeiro falha 500, segundo 200 ok
    html_capa = """
    <html><body>
        <a href="/artigo-1">Link 1</a>
        <a href="/artigo-2">Link 2</a>
    </body></html>
    """
    html_artigo_2 = HTML_NOTICIA_COMPLETA

    http_mock = MagicMock()
    http_mock.fetch.side_effect = [
        (True, html_capa, 200, "https://portalteste.com.br"),        # Capa
        (False, "Erro 500 interno", 500, None),                       # Artigo 1 (falha isolada)
        (True, html_artigo_2, 200, "https://portalteste.com.br/artigo-2"),  # Artigo 2 (sucesso)
    ]

    itens = collect_source(
        source_cfg=source_cfg,
        settings=settings,
        http_collector=http_mock,
        selenium_collector=None,
        deduplicator=dedup,
        metrics=metrics,
    )

    # O pipeline NÃO abortou: registrou a falha e coletou o segundo artigo
    assert metrics.errors_count == 1
    assert len(itens) == 1
    assert itens[0].url == "https://portalteste.com.br/artigo-2"


# ── 10. Encerramento correto dos recursos do Selenium ───────────────────────

def test_encerramento_correto_recursos_selenium():
    collector = SeleniumCollector(headless=True)
    mock_driver = MagicMock()
    collector._driver = mock_driver

    # Encerramento manual
    collector.close()
    mock_driver.quit.assert_called_once()
    assert collector._driver is None

    # Encerramento com context manager
    with SeleniumCollector(headless=True) as col:
        col._driver = mock_driver
    assert col._driver is None
